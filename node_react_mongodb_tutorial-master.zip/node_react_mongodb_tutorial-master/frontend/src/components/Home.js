import React from 'react';

function Home() {
    return(
        <section>
            <div class="container-fluid">
                <h1 class="mt-5">Welcome</h1>
                <p>This site was created using Node JS with React and MongoDB.</p>
            </div>
        </section>
    );
}

export default Home;